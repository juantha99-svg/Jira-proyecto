

## Sistema de Arrendamiento de Espacios de Trabajo




## Contexto
Agencia de arrendamiento de espacios de trabajo (oficinas, coworking, salas de reunión)

## PROBLEMA
Los clientes no tienen una forma rápida y clara de consultar disponibilidad y reservar espacios de trabajo, lo que genera desorden, mala gestión del tiempo y pérdida de oportunidades.

## USUARIOS
- **Clientes**: buscan espacios de trabajo disponibles (oficinas, salas, coworking) y desean reservarlos de forma rápida.
- **Administrador**: gestiona precios, disponibilidad, horarios y reservas de los espacios.

## OBJETIVO
Permitir a los usuarios consultar disponibilidad en tiempo real, reservar espacios de trabajo y gestionar sus reservas de forma simple y eficiente.

## MVP (Producto Mínimo Viable)
- Ver disponibilidad de espacios de trabajo  
- Crear reserva  
- Cancelar reserva  
- Consultar precios  


 ## Product Backlog



Alta:

Ver disponibilidad
Realizar reserva
Consultar precios


Media:

Cancelar reserva
Notificación de reserva
Modificar reserva


Baja:

Historial de cambios
Navegación intuitiva


## 3. Planificación del Sprint

Sprint Goal

Permitir al usuario consultar disponibilidad y realizar reservas de forma básica.

Historias seleccionadas: 

Ver disponibilidad
Realizar reserva
Cancelar reserva
Consultar precios

## Subtareas:


- Diseñar la interfaz para visualizar registros de cambios de fecha y horario.
- Realizar pruebas de visualización y auditoría de registros de cambios
- Implementar validación de disponibilidad de horario
- Confirmar y mostrar mensaje de éxito al usuario
- Validar la recepción y visualización de la confirmación por el usuario
- Como cliente, quiero ver los horarios disponibles, para elegir el mejor momento para reservar.
- Realizar pruebas de visualización y actualización de horarios
- Implementar validaciones de datos en el formulario de reserva
- Mostrar mensajes de error claros y útiles al usuario
- Implementar la lógica para editar y guardar precios de servicios
- Diseñar el flujo de solicitud de reembolso en la interfaz de usuario





##  Ejecución del Sprint


Se inició el sprint en Jira

Se asignaron tareas entre los integrantes: Juan Esteban Tabares - Leidy Restrepo

Se movieron tareas entre estados: To Do → In Progress → Done

Se registraron avances mediante comentarios

## Sprint Review

Se completaron las siguientes funcionalidades:

Visualización de espacios de trabajo
Creación de reservas
Cancelación de reservas
Consulta de precios





##  Funcionalidad Implementada

Se desarrolló una aplicación web utilizando:

HTML
CSS
JavaScript

Características:

Catálogo de espacios de trabajo (3 espacios)
Visualización con imágenes
Sistema de reservas
Cancelación de reservas




