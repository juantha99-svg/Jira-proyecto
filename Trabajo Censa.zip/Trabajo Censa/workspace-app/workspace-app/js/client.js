// ═══════════════════════════════════════════
//  CLIENT PAGE — client.js
// ═══════════════════════════════════════════

// ── Init select espacios ──
function initSelectEspacios() {
  const sel = document.getElementById('sel-espacio');
  sel.innerHTML = '<option value="">— Selecciona un espacio —</option>';
  DB.espacios.filter(e => e.activo).forEach(e => {
    const opt = document.createElement('option');
    opt.value = e.id;
    opt.textContent = e.nombre;
    sel.appendChild(opt);
  });
}

// ── Render galería ──
function renderGallery() {
  const grid = document.getElementById('gallery-grid');
  const espacios = DB.espacios;
  grid.innerHTML = espacios.map(e => {
    const slots = getSlots(e.id, hoyStr());
    const slotsHtml = slots.map(s =>
      `<span class="slot ${s.libre ? 'libre' : 'ocupado'}">${s.hora}</span>`
    ).join('');
    return `
    <div class="card${!e.activo ? ' inactive' : ''}" id="card-${e.id}" onclick="${e.activo ? `seleccionarCard(${e.id})` : ''}">
      <div class="card-badge">${e.badge}</div>
      ${!e.activo ? '<div class="card-inactive-tag">No disponible</div>' : ''}
      <div class="card-img-wrap">
        <img src="${e.imagen}" alt="${e.nombre}" loading="lazy">
      </div>
      <div class="card-body">
        <h3 class="card-name">${e.nombre}</h3>
        <p class="card-desc">${e.descripcion}</p>
        <p style="font-size:0.68rem;color:var(--muted);margin-bottom:0.5rem;letter-spacing:0.05em;text-transform:uppercase;">Disponibilidad hoy</p>
        <div class="avail-strip">${slotsHtml}</div>
        <div class="card-footer">
          <div class="price">
            ${formatCOP(e.precio)}
            <small>/ hora</small>
          </div>
          <button class="btn-select${!e.activo ? ' disabled' : ''}" id="btn-${e.id}">
            ${e.activo ? 'Reservar' : 'No disponible'}
          </button>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ── Seleccionar card ──
function seleccionarCard(id) {
  DB.espacios.forEach(e => {
    document.getElementById(`card-${e.id}`)?.classList.remove('selected');
    const btn = document.getElementById(`btn-${e.id}`);
    if (btn) { btn.textContent = 'Reservar'; btn.classList.remove('active'); }
  });

  document.getElementById(`card-${id}`)?.classList.add('selected');
  const btn = document.getElementById(`btn-${id}`);
  if (btn) { btn.textContent = '✓ Elegido'; btn.classList.add('active'); }

  document.getElementById('sel-espacio').value = id;
  actualizarHoras();
  document.getElementById('reservar').scrollIntoView({ behavior: 'smooth' });
}

// ── Actualizar horas ──
function actualizarHoras() {
  const espacioId = document.getElementById('sel-espacio').value;
  const fecha = document.getElementById('inp-fecha').value;
  const sel = document.getElementById('inp-hora');
  sel.innerHTML = '<option value="">— Hora —</option>';
  if (!espacioId || !fecha) return;

  const slots = getSlots(parseInt(espacioId), fecha);
  slots.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.hora;
    opt.textContent = s.libre ? s.hora : `${s.hora} — Ocupado`;
    opt.disabled = !s.libre;
    sel.appendChild(opt);
  });
}

// ── Realizar reserva ──
function realizarReserva() {
  const espacioId = parseInt(document.getElementById('sel-espacio').value);
  const fecha     = document.getElementById('inp-fecha').value;
  const hora      = document.getElementById('inp-hora').value;
  const nombre    = document.getElementById('inp-nombre').value.trim();
  const correo    = document.getElementById('inp-correo').value.trim();

  if (!espacioId) return mostrarNotifClient("Por favor selecciona un espacio.", true);
  if (!fecha)     return mostrarNotifClient("Por favor ingresa una fecha.", true);
  if (!hora)      return mostrarNotifClient("Por favor selecciona una hora disponible.", true);
  if (!nombre)    return mostrarNotifClient("Por favor ingresa tu nombre.", true);
  if (!correo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo))
                  return mostrarNotifClient("Por favor ingresa un correo válido.", true);

  const dup = DB.reservas.find(r => r.espacioId === espacioId && r.fecha === fecha && r.hora === hora && r.estado === 'activa');
  if (dup) return mostrarNotifClient("Ese horario ya está ocupado. Elige otra hora.", true);

  const reservas = DB.reservas;
  const nueva = { id: 'r' + Date.now(), espacioId, fecha, hora, nombre, correo, estado: 'activa' };
  reservas.push(nueva);
  DB.reservas = reservas;

  const espacio = DB.espacios.find(e => e.id === espacioId);
  mostrarNotifClient(`✓ Reserva confirmada — ${espacio.nombre} · ${fecha} a las ${hora}. ¡Te esperamos, ${nombre}!`);

  // Limpiar
  document.getElementById('sel-espacio').value = '';
  document.getElementById('inp-fecha').value = '';
  document.getElementById('inp-hora').innerHTML = '<option value="">— Hora —</option>';
  document.getElementById('inp-nombre').value = '';
  document.getElementById('inp-correo').value = '';

  renderGallery();
  renderReservasCliente();
}

// ── Cancelar reserva (cliente) ──
function cancelarReservaCliente(id) {
  const reservas = DB.reservas;
  const idx = reservas.findIndex(r => r.id === id);
  if (idx === -1) return;
  reservas.splice(idx, 1);
  DB.reservas = reservas;
  renderGallery();
  renderReservasCliente();
}

// ── Render mis reservas ──
function renderReservasCliente() {
  const lista = document.getElementById('lista-reservas');
  const reservas = DB.reservas.filter(r => r.estado === 'activa');
  if (reservas.length === 0) {
    lista.innerHTML = '<p class="empty-state" style="grid-column:1/-1">No hay reservas activas.</p>';
    return;
  }
  lista.innerHTML = reservas.map(r => {
    const espacio = DB.espacios.find(e => e.id === r.espacioId);
    return `
    <div class="reserva-card">
      <button class="btn btn-danger" style="position:absolute;top:1rem;right:1rem" onclick="cancelarReservaCliente('${r.id}')">Cancelar</button>
      <h4>${espacio?.nombre ?? 'Espacio'}</h4>
      <div class="reserva-detail">
        <strong>Fecha:</strong> ${r.fecha}<br>
        <strong>Hora:</strong> ${r.hora}<br>
        <strong>Nombre:</strong> ${r.nombre}<br>
        <strong>Correo:</strong> ${r.correo}<br>
        <strong>Total:</strong> ${espacio ? formatCOP(espacio.precio) : '—'}
      </div>
    </div>`;
  }).join('');
}

// ── Notificación cliente ──
function mostrarNotifClient(msg, err = false) {
  const n = document.getElementById('notif-client');
  n.textContent = msg;
  n.className = 'notif show ' + (err ? 'err' : 'ok');
  clearTimeout(n._t);
  n._t = setTimeout(() => n.classList.remove('show'), 5500);
}

// ── Listeners ──
document.getElementById('sel-espacio').addEventListener('change', () => {
  const id = parseInt(document.getElementById('sel-espacio').value);
  DB.espacios.forEach(e => {
    document.getElementById(`card-${e.id}`)?.classList.remove('selected');
    const btn = document.getElementById(`btn-${e.id}`);
    if (btn && e.activo) { btn.textContent = 'Reservar'; btn.classList.remove('active'); }
  });
  if (id) {
    document.getElementById(`card-${id}`)?.classList.add('selected');
    const btn = document.getElementById(`btn-${id}`);
    if (btn) { btn.textContent = '✓ Elegido'; btn.classList.add('active'); }
  }
  actualizarHoras();
});

document.getElementById('inp-fecha').addEventListener('change', actualizarHoras);
document.getElementById('inp-fecha').min = hoyStr();

// ── Boot ──
initSelectEspacios();
renderGallery();
renderReservasCliente();
