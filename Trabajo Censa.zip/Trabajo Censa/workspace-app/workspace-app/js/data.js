// ═══════════════════════════════════════════
//  DATA STORE — compartido entre todas las páginas
// ═══════════════════════════════════════════

const ESPACIOS_DEFAULT = [
  {
    id: 1,
    nombre: "Escritorio Individual",
    precio: 50000,
    descripcion: "Espacio de trabajo individual con acceso a WiFi, ambiente tranquilo y zona compartida.",
    imagen: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80",
    badge: "Popular",
    tipo: "Escritorio",
    activo: true
  },
  {
    id: 2,
    nombre: "Oficina Privada",
    precio: 50000,
    descripcion: "Oficina cerrada para trabajo individual o en pareja, con mayor privacidad y concentración.",
    imagen: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=600&q=80",
    badge: "Privacidad",
    tipo: "Oficina",
    activo: true
  },
  {
    id: 3,
    nombre: "Sala de Reuniones",
    precio: 100000,
    descripcion: "Sala amplia para reuniones de equipo, con capacidad para varias personas y proyector.",
    imagen: "https://images.unsplash.com/photo-1517502884422-41eaead166d4?w=600&q=80",
    badge: "Gran Aforo",
    tipo: "Sala",
    activo: true
  }
];

const HORAS = [
  "08:00","09:00","10:00","11:00","12:00",
  "13:00","14:00","15:00","16:00","17:00","18:00"
];

// ── Credenciales admin (demo) ──
const ADMIN_CREDENTIALS = { user: "admin", pass: "workspace2025" };

// ── Helpers de localStorage ──
function lsGet(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ── Estado global ──
const DB = {
  get espacios() { return lsGet('ws_espacios', ESPACIOS_DEFAULT); },
  set espacios(v) { lsSet('ws_espacios', v); },

  get reservas() { return lsGet('ws_reservas', [
    { id: 'r001', espacioId: 1, fecha: hoyStr(), hora: '09:00', nombre: 'María López', correo: 'maria@mail.com', estado: 'activa' },
    { id: 'r002', espacioId: 2, fecha: hoyStr(), hora: '11:00', nombre: 'Carlos Ríos', correo: 'carlos@mail.com', estado: 'activa' },
    { id: 'r003', espacioId: 3, fecha: hoyStr(), hora: '14:00', nombre: 'Ana Gómez',   correo: 'ana@mail.com',    estado: 'activa' },
  ]); },
  set reservas(v) { lsSet('ws_reservas', v); },

  get bloqueos() { return lsGet('ws_bloqueos', []); },
  set bloqueos(v) { lsSet('ws_bloqueos', v); },

  get adminLoggedIn() { return lsGet('ws_admin', false); },
  set adminLoggedIn(v) { lsSet('ws_admin', v); },
};

function hoyStr() {
  return new Date().toISOString().split('T')[0];
}

function getSlots(espacioId, fecha) {
  const reservasOcupadas = DB.reservas
    .filter(r => r.espacioId == espacioId && r.fecha === fecha && r.estado === 'activa')
    .map(r => r.hora);
  const bloqueosOcupados = DB.bloqueos
    .filter(b => b.espacioId == espacioId && b.fecha === fecha)
    .map(b => b.hora);
  const ocupadas = [...new Set([...reservasOcupadas, ...bloqueosOcupados])];
  return HORAS.map(h => ({ hora: h, libre: !ocupadas.includes(h) }));
}

function formatCOP(n) {
  return '$' + Number(n).toLocaleString('es-CO') + ' COP';
}
