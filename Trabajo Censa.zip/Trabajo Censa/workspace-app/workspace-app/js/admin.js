// ═══════════════════════════════════════════
//  ADMIN PANEL — admin.js
// ═══════════════════════════════════════════

// ── Auth guard ──
function checkAuth() {
  if (!DB.adminLoggedIn) {
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('admin-app').style.display = 'none';
  } else {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('admin-app').style.display = 'block';
    bootAdmin();
  }
}

function doLogin() {
  const u = document.getElementById('login-user').value.trim();
  const p = document.getElementById('login-pass').value.trim();
  const n = document.getElementById('login-notif');

  if (u === ADMIN_CREDENTIALS.user && p === ADMIN_CREDENTIALS.pass) {
    DB.adminLoggedIn = true;
    checkAuth();
  } else {
    n.textContent = 'Usuario o contraseña incorrectos.';
    n.className = 'notif show err';
  }
}

function doLogout() {
  DB.adminLoggedIn = false;
  checkAuth();
}

// Enter key en login
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && document.getElementById('login-screen').style.display !== 'none') {
    doLogin();
  }
});

// ── Navigation ──
function navigate(tab) {
  document.querySelectorAll('.sidebar-item').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(el => el.classList.remove('active'));
  document.querySelector(`[data-tab="${tab}"]`)?.classList.add('active');
  document.getElementById(`tab-${tab}`)?.classList.add('active');

  const titles = {
    dashboard: { title: 'Panel de <em>Control</em>', sub: 'Resumen de operación y métricas clave' },
    reservas:  { title: 'Gestión de <em>Reservas</em>', sub: 'Visualiza, filtra y administra todas las reservas' },
    espacios:  { title: 'Gestión de <em>Espacios</em>', sub: 'Crea, edita y activa/desactiva los espacios del catálogo' },
    bloqueos:  { title: 'Bloqueo de <em>Horarios</em>', sub: 'Bloquea franjas por mantenimiento o eventos especiales' },
    clientes:  { title: 'Gestión de <em>Clientes</em>', sub: 'Historial de personas que han reservado' },
  };
  const t = titles[tab];
  if (t) {
    document.getElementById('page-title').innerHTML = t.title;
    document.getElementById('page-sub').textContent = t.sub;
  }

  const renderers = { dashboard: renderDashboard, reservas: renderReservasAdmin, espacios: renderEspaciosAdmin, bloqueos: renderBloqueos, clientes: renderClientes };
  renderers[tab]?.();
}

// ── DASHBOARD ──
function renderDashboard() {
  const reservas = DB.reservas;
  const espacios = DB.espacios;
  const hoy = hoyStr();
  const hoyReservas = reservas.filter(r => r.fecha === hoy && r.estado === 'activa');
  const totalIngresos = reservas.filter(r => r.estado === 'activa').reduce((sum, r) => {
    const e = espacios.find(x => x.id === r.espacioId);
    return sum + (e ? e.precio : 0);
  }, 0);

  const clientes = [...new Set(reservas.map(r => r.correo))].length;

  document.getElementById('kpi-hoy').textContent       = hoyReservas.length;
  document.getElementById('kpi-total').textContent     = reservas.filter(r => r.estado === 'activa').length;
  document.getElementById('kpi-ingresos').textContent  = '$' + totalIngresos.toLocaleString('es-CO');
  document.getElementById('kpi-clientes').textContent  = clientes;

  // Bar chart por espacio
  const barWrap = document.getElementById('chart-espacios');
  const maxVal = Math.max(...espacios.map(e => reservas.filter(r => r.espacioId === e.id && r.estado === 'activa').length), 1);
  barWrap.innerHTML = espacios.map(e => {
    const count = reservas.filter(r => r.espacioId === e.id && r.estado === 'activa').length;
    const pct = (count / maxVal * 100).toFixed(0);
    return `
    <div class="bar-row">
      <span class="bar-label">${e.nombre}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
      <span class="bar-val">${count} reservas</span>
    </div>`;
  }).join('');

  // Hours heatmap
  const hoursWrap = document.getElementById('chart-horas');
  const hourCounts = {};
  HORAS.forEach(h => hourCounts[h] = 0);
  reservas.filter(r => r.estado === 'activa').forEach(r => {
    if (hourCounts[r.hora] !== undefined) hourCounts[r.hora]++;
  });
  const maxH = Math.max(...Object.values(hourCounts), 1);
  hoursWrap.innerHTML = HORAS.map(h => {
    const c = hourCounts[h];
    const cls = c >= maxH * 0.7 ? 'hot' : c >= maxH * 0.3 ? 'warm' : '';
    return `<div class="hour-cell ${cls}">${h}<br><strong>${c}</strong></div>`;
  }).join('');

  // Recent activity
  const actWrap = document.getElementById('recent-activity');
  const recent = [...reservas].reverse().slice(0, 5);
  if (!recent.length) { actWrap.innerHTML = '<tr><td colspan="4" style="color:var(--muted);font-style:italic;padding:1.5rem">Sin actividad reciente.</td></tr>'; return; }
  actWrap.innerHTML = recent.map(r => {
    const e = espacios.find(x => x.id === r.espacioId);
    return `<tr>
      <td>${r.nombre}</td>
      <td>${e?.nombre ?? '—'}</td>
      <td>${r.fecha} · ${r.hora}</td>
      <td><span class="badge badge-ok">Activa</span></td>
    </tr>`;
  }).join('');
}

// ── RESERVAS ADMIN ──
let filtroReserva = '';
function renderReservasAdmin() {
  const reservas = DB.reservas;
  const espacios = DB.espacios;
  const tbody = document.getElementById('reservas-tbody');
  const f = filtroReserva.toLowerCase();

  const filtradas = reservas.filter(r =>
    !f ||
    r.nombre.toLowerCase().includes(f) ||
    r.correo.toLowerCase().includes(f) ||
    r.fecha.includes(f) ||
    (espacios.find(e => e.id === r.espacioId)?.nombre ?? '').toLowerCase().includes(f)
  );

  if (!filtradas.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="color:var(--muted);font-style:italic;padding:1.5rem">Sin reservas.</td></tr>';
    return;
  }
  tbody.innerHTML = filtradas.map(r => {
    const e = espacios.find(x => x.id === r.espacioId);
    const badgeCls = r.estado === 'activa' ? 'badge-ok' : 'badge-err';
    return `<tr>
      <td><strong>${r.nombre}</strong><br><span style="font-size:0.75rem;color:var(--muted)">${r.correo}</span></td>
      <td>${e?.nombre ?? '—'}</td>
      <td>${r.fecha}</td>
      <td>${r.hora}</td>
      <td>${e ? formatCOP(e.precio) : '—'}</td>
      <td>
        <span class="badge ${badgeCls}">${r.estado}</span>
        ${r.estado === 'activa' ? `<button class="btn btn-danger" style="margin-left:0.5rem" onclick="cancelarReservaAdmin('${r.id}')">Cancelar</button>` : ''}
      </td>
    </tr>`;
  }).join('');
}

function cancelarReservaAdmin(id) {
  const reservas = DB.reservas;
  const idx = reservas.findIndex(r => r.id === id);
  if (idx === -1) return;
  reservas[idx].estado = 'cancelada';
  DB.reservas = reservas;
  renderReservasAdmin();
  mostrarNotifAdmin('Reserva cancelada correctamente.');
}

document.getElementById('filter-reservas')?.addEventListener('input', e => {
  filtroReserva = e.target.value;
  renderReservasAdmin();
});

// ── ESPACIOS ADMIN ──
function renderEspaciosAdmin() {
  const grid = document.getElementById('espacios-admin-grid');
  const espacios = DB.espacios;
  grid.innerHTML = espacios.map(e => `
    <div class="space-admin-card${!e.activo ? ' inactive' : ''}">
      <img class="space-admin-img" src="${e.imagen}" alt="${e.nombre}">
      <div class="space-admin-body">
        <div class="space-admin-name">${e.nombre}</div>
        <div class="space-admin-price">${formatCOP(e.precio)} / hora</div>
        <div class="space-admin-actions">
          <button class="btn btn-ghost" onclick="abrirModalEspacio(${e.id})">✏️ Editar</button>
          <button class="btn ${e.activo ? 'btn-danger' : 'btn-success'}" onclick="toggleEspacio(${e.id})">
            ${e.activo ? '⛔ Desactivar' : '✅ Activar'}
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function toggleEspacio(id) {
  const espacios = DB.espacios;
  const idx = espacios.findIndex(e => e.id === id);
  if (idx === -1) return;
  espacios[idx].activo = !espacios[idx].activo;
  DB.espacios = espacios;
  renderEspaciosAdmin();
  mostrarNotifAdmin(`Espacio ${espacios[idx].activo ? 'activado' : 'desactivado'} correctamente.`);
}

function abrirModalEspacio(id) {
  const espacio = DB.espacios.find(e => e.id === id);
  if (!espacio) return;
  document.getElementById('modal-eid').value      = espacio.id;
  document.getElementById('modal-enombre').value  = espacio.nombre;
  document.getElementById('modal-eprecio').value  = espacio.precio;
  document.getElementById('modal-edesc').value    = espacio.descripcion;
  document.getElementById('modal-eimagen').value  = espacio.imagen;
  document.getElementById('modal-espacio').classList.add('open');
}

function cerrarModalEspacio() {
  document.getElementById('modal-espacio').classList.remove('open');
}

function guardarEspacio() {
  const id      = parseInt(document.getElementById('modal-eid').value);
  const nombre  = document.getElementById('modal-enombre').value.trim();
  const precio  = parseInt(document.getElementById('modal-eprecio').value);
  const desc    = document.getElementById('modal-edesc').value.trim();
  const imagen  = document.getElementById('modal-eimagen').value.trim();

  if (!nombre || !precio || !desc || !imagen)
    return mostrarNotifAdmin('Completa todos los campos del espacio.', true);

  const espacios = DB.espacios;
  const idx = espacios.findIndex(e => e.id === id);
  if (idx === -1) return;
  espacios[idx] = { ...espacios[idx], nombre, precio, descripcion: desc, imagen };
  DB.espacios = espacios;
  cerrarModalEspacio();
  renderEspaciosAdmin();
  mostrarNotifAdmin('Espacio actualizado correctamente.');
}

// ── BLOQUEOS ──
function renderBloqueos() {
  const bloqueos = DB.bloqueos;
  const espacios = DB.espacios;
  const tbody = document.getElementById('bloqueos-tbody');

  // Poblar selects
  ['blk-espacio'].forEach(selId => {
    const sel = document.getElementById(selId);
    if (sel && !sel.options.length) {
      espacios.forEach(e => {
        const opt = document.createElement('option');
        opt.value = e.id; opt.textContent = e.nombre;
        sel.appendChild(opt);
      });
    }
  });

  if (!bloqueos.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="color:var(--muted);font-style:italic;padding:1.5rem">Sin bloqueos registrados.</td></tr>';
    return;
  }
  tbody.innerHTML = bloqueos.map((b, i) => {
    const e = espacios.find(x => x.id == b.espacioId);
    return `<tr>
      <td>${e?.nombre ?? '—'}</td>
      <td>${b.fecha}</td>
      <td>${b.hora}</td>
      <td>${b.motivo || '—'}</td>
      <td><button class="btn btn-danger" onclick="eliminarBloqueo(${i})">Eliminar</button></td>
    </tr>`;
  }).join('');
}

function agregarBloqueo() {
  const espacioId = parseInt(document.getElementById('blk-espacio').value);
  const fecha     = document.getElementById('blk-fecha').value;
  const hora      = document.getElementById('blk-hora').value;
  const motivo    = document.getElementById('blk-motivo').value.trim();

  if (!espacioId || !fecha || !hora)
    return mostrarNotifAdmin('Completa espacio, fecha y hora.', true);

  const bloqueos = DB.bloqueos;
  bloqueos.push({ espacioId, fecha, hora, motivo: motivo || 'Mantenimiento' });
  DB.bloqueos = bloqueos;

  document.getElementById('blk-fecha').value  = '';
  document.getElementById('blk-hora').value   = '';
  document.getElementById('blk-motivo').value = '';

  renderBloqueos();
  mostrarNotifAdmin('Bloqueo registrado correctamente.');
}

function eliminarBloqueo(idx) {
  const bloqueos = DB.bloqueos;
  bloqueos.splice(idx, 1);
  DB.bloqueos = bloqueos;
  renderBloqueos();
  mostrarNotifAdmin('Bloqueo eliminado.');
}

// Poblar select de horas en bloqueos
window.addEventListener('DOMContentLoaded', () => {
  const sel = document.getElementById('blk-hora');
  if (sel) HORAS.forEach(h => { const o = document.createElement('option'); o.value = h; o.textContent = h; sel.appendChild(o); });
});

// ── CLIENTES ──
function renderClientes() {
  const reservas = DB.reservas;
  const tbody = document.getElementById('clientes-tbody');

  // Agrupar por correo
  const mapa = {};
  reservas.forEach(r => {
    if (!mapa[r.correo]) mapa[r.correo] = { nombre: r.nombre, correo: r.correo, reservas: [] };
    mapa[r.correo].reservas.push(r);
  });

  const clientes = Object.values(mapa);
  if (!clientes.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="color:var(--muted);font-style:italic;padding:1.5rem">Sin clientes registrados.</td></tr>';
    return;
  }

  tbody.innerHTML = clientes.map(c => {
    const activas = c.reservas.filter(r => r.estado === 'activa').length;
    const inicial = c.nombre.charAt(0).toUpperCase();
    return `<tr>
      <td><span class="client-avatar">${inicial}</span>${c.nombre}</td>
      <td>${c.correo}</td>
      <td>${c.reservas.length} total · ${activas} activa${activas !== 1 ? 's' : ''}</td>
      <td>${c.reservas[c.reservas.length - 1].fecha}</td>
    </tr>`;
  }).join('');
}

// ── Notificación admin ──
function mostrarNotifAdmin(msg, err = false) {
  const n = document.getElementById('notif-admin');
  if (!n) return;
  n.textContent = msg;
  n.className = 'notif show ' + (err ? 'err' : 'ok');
  clearTimeout(n._t);
  n._t = setTimeout(() => n.classList.remove('show'), 4500);
}

// ── Boot ──
function bootAdmin() {
  navigate('dashboard');
}

// ── Init ──
checkAuth();
